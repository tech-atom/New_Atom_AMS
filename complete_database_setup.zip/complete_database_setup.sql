-- ============================================
-- COMPLETE DATABASE SETUP SCRIPT
-- LMS System - Full Database Schema
-- ============================================
-- This file contains all tables used in the LMS application
-- Created: December 26, 2025
-- ============================================

-- Create Database
CREATE DATABASE IF NOT EXISTS lms_system;
USE lms_system;

-- ============================================
-- 1. ADMIN TABLE
-- ============================================
-- Stores admin user credentials for system access
CREATE TABLE IF NOT EXISTS admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Admin users table';

-- ============================================
-- 2. STUDENTS TABLE
-- ============================================
-- Stores student information and credentials
CREATE TABLE IF NOT EXISTS students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    course VARCHAR(100),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_course (course)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Student users table';

-- ============================================
-- 3. REGISTRATION FIELDS TABLE
-- ============================================
-- Manages custom registration form fields
CREATE TABLE IF NOT EXISTS registration_fields (
    field_id INT AUTO_INCREMENT PRIMARY KEY,
    field_name VARCHAR(100) NOT NULL,
    field_label VARCHAR(200) NOT NULL,
    field_type ENUM('text', 'email', 'number', 'tel', 'date', 'select', 'textarea') DEFAULT 'text',
    field_options TEXT,
    is_required BOOLEAN DEFAULT TRUE,
    field_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_field_name (field_name),
    INDEX idx_field_order (field_order),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Custom registration form fields';

-- ============================================
-- 4. STUDENT CUSTOM DATA TABLE
-- ============================================
-- Stores values for custom registration fields per student
CREATE TABLE IF NOT EXISTS student_custom_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    field_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    UNIQUE KEY unique_student_field (student_id, field_name),
    INDEX idx_student_id (student_id),
    INDEX idx_field_name (field_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Custom field values for each student';

-- ============================================
-- 5. COURSES TABLE
-- ============================================
-- Stores available courses in the system
CREATE TABLE IF NOT EXISTS courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_course_name (course_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Available courses';

-- ============================================
-- 6. MATERIALS TABLE
-- ============================================
-- Stores learning materials and resources
CREATE TABLE IF NOT EXISTS materials (
    material_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    file_path VARCHAR(500),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_title (title)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Learning materials and files';

-- ============================================
-- 7. LECTURE VIDEOS TABLE
-- ============================================
-- Stores lecture video information
CREATE TABLE IF NOT EXISTS lecture_videos (
    video_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    video_url VARCHAR(500),
    description TEXT,
    course_id INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    INDEX idx_course_id (course_id),
    INDEX idx_title (title)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Video lecture content';

-- ============================================
-- 8. EXAM TABLE (Main Exam Information)
-- ============================================
-- Stores exam metadata and configuration
CREATE TABLE IF NOT EXISTS exam (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_title VARCHAR(200) NOT NULL,
    subject_name VARCHAR(100),
    show_scores TINYINT(1) DEFAULT 1 COMMENT '1=show scores, 0=hide scores',
    courses TEXT COMMENT 'Comma-separated course names for targeting specific courses',
    question_paper_path VARCHAR(500) COMMENT 'Path to uploaded question paper file',
    start_datetime DATETIME COMMENT 'Exam availability start time',
    end_datetime DATETIME COMMENT 'Exam deadline/close time',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_exam_title (exam_title),
    INDEX idx_subject (subject_name),
    INDEX idx_start_datetime (start_datetime),
    INDEX idx_end_datetime (end_datetime)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Main exam information and settings';

-- ============================================
-- 9. EXAMS TABLE (Legacy - for backward compatibility)
-- ============================================
-- Old structure with question data embedded
-- Kept for backward compatibility with older exam data
CREATE TABLE IF NOT EXISTS exams (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_title VARCHAR(200) NOT NULL,
    subject VARCHAR(100),
    question_text TEXT,
    option_a VARCHAR(255),
    option_b VARCHAR(255),
    option_c VARCHAR(255),
    option_d VARCHAR(255),
    correct_option VARCHAR(1),
    explanation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_exam_title (exam_title),
    INDEX idx_subject (subject)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Legacy exam table with embedded questions';

-- ============================================
-- 10. QUESTIONS TABLE
-- ============================================
-- Stores individual questions for each exam
CREATE TABLE IF NOT EXISTS questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    question_text TEXT NOT NULL,
    option_a VARCHAR(255),
    option_b VARCHAR(255),
    option_c VARCHAR(255),
    option_d VARCHAR(255),
    correct_option VARCHAR(10) COMMENT 'Can store A, B, C, D or multiple answers',
    explanation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES exam(exam_id) ON DELETE CASCADE,
    INDEX idx_exam_id (exam_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Questions for each exam';

-- ============================================
-- 11. RESULTS TABLE (Legacy)
-- ============================================
-- Legacy results table - kept for backward compatibility
CREATE TABLE IF NOT EXISTS results (
    result_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    student_answer VARCHAR(1),
    is_correct TINYINT(1) DEFAULT 0,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES exams(exam_id) ON DELETE CASCADE,
    INDEX idx_exam_id (exam_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Legacy results table';

-- ============================================
-- 12. STUDENT RESPONSES TABLE
-- ============================================
-- Stores student answers for each question in an exam
CREATE TABLE IF NOT EXISTS student_responses (
    response_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    exam_id INT NOT NULL,
    question_id INT NOT NULL,
    selected_option TEXT COMMENT 'Can store A, B, C, D or descriptive answers',
    is_correct TINYINT(1) DEFAULT 0,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (exam_id) REFERENCES exam(exam_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE,
    INDEX idx_student_id (student_id),
    INDEX idx_exam_id (exam_id),
    INDEX idx_question_id (question_id),
    INDEX idx_student_exam (student_id, exam_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Student answers for each question';

-- ============================================
-- 13. STUDENT PERFORMANCE TABLE
-- ============================================
-- Aggregated performance data for each student per exam
CREATE TABLE IF NOT EXISTS student_performance (
    performance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    student_name VARCHAR(100),
    exam_id INT NOT NULL,
    total_questions INT DEFAULT 0,
    correct_answers INT DEFAULT 0,
    incorrect_answers INT DEFAULT 0,
    score DECIMAL(5,2) DEFAULT 0,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (exam_id) REFERENCES exam(exam_id) ON DELETE CASCADE,
    UNIQUE KEY unique_student_exam (student_id, exam_id),
    INDEX idx_student_id (student_id),
    INDEX idx_exam_id (exam_id),
    INDEX idx_score (score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Aggregated exam performance per student';

-- ============================================
-- 14. CODING RESULTS TABLE
-- ============================================
-- Stores results from coding problem submissions
CREATE TABLE IF NOT EXISTS coding_results (
    coding_result_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    problem_title VARCHAR(200),
    code_submitted TEXT,
    test_cases_passed INT DEFAULT 0,
    total_test_cases INT DEFAULT 0,
    score DECIMAL(5,2) DEFAULT 0,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    INDEX idx_student_id (student_id),
    INDEX idx_problem_title (problem_title)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Coding problem submission results';

-- ============================================
-- 15. ANNOUNCEMENTS TABLE
-- ============================================
-- Stores system and course-specific announcements
CREATE TABLE IF NOT EXISTS announcements (
    announcement_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    course VARCHAR(100) COMMENT 'Specific course or NULL for all students',
    is_pinned BOOLEAN DEFAULT FALSE,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_course (course),
    INDEX idx_pinned (is_pinned),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='System and course announcements';

-- ============================================
-- 16. ANNOUNCEMENT READS TABLE
-- ============================================
-- Tracks which students have read which announcements
CREATE TABLE IF NOT EXISTS announcement_reads (
    read_id INT AUTO_INCREMENT PRIMARY KEY,
    announcement_id INT NOT NULL,
    student_id INT NOT NULL,
    read_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (announcement_id) REFERENCES announcements(announcement_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    UNIQUE KEY unique_read (announcement_id, student_id),
    INDEX idx_announcement_id (announcement_id),
    INDEX idx_student_id (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Tracks announcement read status';

-- ============================================
-- DEFAULT DATA INSERTION
-- ============================================

-- Insert Default Admin User (username: admin, password: admin123)
INSERT INTO admin (username, password) VALUES ('admin', 'admin123') 
ON DUPLICATE KEY UPDATE username=username;

-- Insert Default Registration Fields
INSERT INTO registration_fields (field_name, field_label, field_type, field_options, is_required, field_order, is_active) VALUES 
('student_name', 'Full Name', 'text', NULL, TRUE, 1, TRUE),
('email', 'Email Address', 'email', NULL, TRUE, 2, TRUE),
('password', 'Password', 'text', NULL, TRUE, 3, TRUE),
('phone', 'Phone Number', 'tel', NULL, FALSE, 4, TRUE),
('roll_number', 'Roll Number', 'text', NULL, FALSE, 5, TRUE)
ON DUPLICATE KEY UPDATE field_name=field_name;

-- Insert Sample Courses
INSERT INTO courses (course_name, description) VALUES 
('Computer Science', 'Introduction to Computer Science and Programming'),
('Data Science', 'Data Analysis and Machine Learning'),
('Web Development', 'Full Stack Web Development'),
('Mobile App Development', 'iOS and Android Development'),
('Artificial Intelligence', 'Machine Learning and Deep Learning')
ON DUPLICATE KEY UPDATE course_name=course_name;

-- ============================================
-- DATABASE VIEWS (Optional - for reporting)
-- ============================================

-- View: Student Performance Summary
CREATE OR REPLACE VIEW vw_student_performance_summary AS
SELECT 
    s.student_id,
    s.name AS student_name,
    s.email,
    s.course,
    COUNT(DISTINCT sp.exam_id) AS total_exams_taken,
    AVG(sp.score) AS average_score,
    MAX(sp.score) AS highest_score,
    MIN(sp.score) AS lowest_score,
    SUM(sp.correct_answers) AS total_correct_answers,
    SUM(sp.total_questions) AS total_questions_attempted
FROM students s
LEFT JOIN student_performance sp ON s.student_id = sp.student_id
WHERE s.status = 'approved'
GROUP BY s.student_id, s.name, s.email, s.course;

-- View: Exam Statistics
CREATE OR REPLACE VIEW vw_exam_statistics AS
SELECT 
    e.exam_id,
    e.exam_title,
    e.subject_name,
    COUNT(DISTINCT q.question_id) AS total_questions,
    COUNT(DISTINCT sp.student_id) AS students_attempted,
    AVG(sp.score) AS average_score,
    MAX(sp.score) AS highest_score,
    MIN(sp.score) AS lowest_score,
    e.start_datetime,
    e.end_datetime,
    e.created_at
FROM exam e
LEFT JOIN questions q ON e.exam_id = q.exam_id
LEFT JOIN student_performance sp ON e.exam_id = sp.exam_id
GROUP BY e.exam_id, e.exam_title, e.subject_name, e.start_datetime, e.end_datetime, e.created_at;

-- View: Pending Student Approvals
CREATE OR REPLACE VIEW vw_pending_students AS
SELECT 
    s.student_id,
    s.name,
    s.email,
    s.course,
    s.created_at,
    COUNT(scd.id) AS custom_fields_count
FROM students s
LEFT JOIN student_custom_data scd ON s.student_id = scd.student_id
WHERE s.status = 'pending'
GROUP BY s.student_id, s.name, s.email, s.course, s.created_at
ORDER BY s.created_at DESC;

-- View: Unread Announcements per Student
CREATE OR REPLACE VIEW vw_unread_announcements AS
SELECT 
    s.student_id,
    s.name AS student_name,
    a.announcement_id,
    a.title,
    a.course,
    a.is_pinned,
    a.created_at
FROM students s
CROSS JOIN announcements a
LEFT JOIN announcement_reads ar ON a.announcement_id = ar.announcement_id 
    AND s.student_id = ar.student_id
WHERE s.status = 'approved'
    AND ar.read_id IS NULL
    AND (a.course IS NULL OR a.course = '' OR a.course = s.course);

-- ============================================
-- STORED PROCEDURES (Optional - for common operations)
-- ============================================

DELIMITER $$

-- Procedure: Calculate Student Score for an Exam
CREATE PROCEDURE IF NOT EXISTS sp_calculate_student_score(
    IN p_student_id INT,
    IN p_exam_id INT
)
BEGIN
    DECLARE v_total_questions INT DEFAULT 0;
    DECLARE v_correct_answers INT DEFAULT 0;
    DECLARE v_incorrect_answers INT DEFAULT 0;
    DECLARE v_score DECIMAL(5,2) DEFAULT 0;
    DECLARE v_student_name VARCHAR(100);
    
    -- Get student name
    SELECT name INTO v_student_name FROM students WHERE student_id = p_student_id;
    
    -- Count total questions for this exam
    SELECT COUNT(*) INTO v_total_questions 
    FROM questions 
    WHERE exam_id = p_exam_id;
    
    -- Count correct and incorrect answers
    SELECT 
        SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END),
        SUM(CASE WHEN is_correct = 0 THEN 1 ELSE 0 END)
    INTO v_correct_answers, v_incorrect_answers
    FROM student_responses
    WHERE student_id = p_student_id AND exam_id = p_exam_id;
    
    -- Calculate score percentage
    IF v_total_questions > 0 THEN
        SET v_score = (v_correct_answers / v_total_questions) * 100;
    END IF;
    
    -- Insert or update performance record
    INSERT INTO student_performance (
        student_id, student_name, exam_id, 
        total_questions, correct_answers, incorrect_answers, score
    ) VALUES (
        p_student_id, v_student_name, p_exam_id,
        v_total_questions, v_correct_answers, v_incorrect_answers, v_score
    ) ON DUPLICATE KEY UPDATE
        total_questions = v_total_questions,
        correct_answers = v_correct_answers,
        incorrect_answers = v_incorrect_answers,
        score = v_score,
        recorded_at = CURRENT_TIMESTAMP;
        
    -- Return the calculated score
    SELECT v_score AS calculated_score;
END$$

-- Procedure: Mark Announcement as Read
CREATE PROCEDURE IF NOT EXISTS sp_mark_announcement_read(
    IN p_announcement_id INT,
    IN p_student_id INT
)
BEGIN
    INSERT INTO announcement_reads (announcement_id, student_id)
    VALUES (p_announcement_id, p_student_id)
    ON DUPLICATE KEY UPDATE read_at = CURRENT_TIMESTAMP;
END$$

-- Procedure: Approve Student Registration
CREATE PROCEDURE IF NOT EXISTS sp_approve_student(
    IN p_student_id INT
)
BEGIN
    UPDATE students 
    SET status = 'approved' 
    WHERE student_id = p_student_id AND status = 'pending';
    
    SELECT ROW_COUNT() AS rows_affected;
END$$

-- Procedure: Reject Student Registration
CREATE PROCEDURE IF NOT EXISTS sp_reject_student(
    IN p_student_id INT
)
BEGIN
    UPDATE students 
    SET status = 'rejected' 
    WHERE student_id = p_student_id AND status = 'pending';
    
    SELECT ROW_COUNT() AS rows_affected;
END$$

DELIMITER ;

-- ============================================
-- TRIGGERS (Optional - for data integrity)
-- ============================================

DELIMITER $$

-- Trigger: Auto-calculate score after student response insertion
CREATE TRIGGER IF NOT EXISTS trg_after_student_response_insert
AFTER INSERT ON student_responses
FOR EACH ROW
BEGIN
    -- This trigger can be used to automatically update performance
    -- Currently handled by application logic
    -- Uncomment if automatic calculation is desired
    -- CALL sp_calculate_student_score(NEW.student_id, NEW.exam_id);
END$$

-- Trigger: Prevent deletion of active exams with student responses
CREATE TRIGGER IF NOT EXISTS trg_before_exam_delete
BEFORE DELETE ON exam
FOR EACH ROW
BEGIN
    DECLARE response_count INT;
    
    SELECT COUNT(*) INTO response_count
    FROM student_responses
    WHERE exam_id = OLD.exam_id;
    
    IF response_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot delete exam with existing student responses';
    END IF;
END$$

DELIMITER ;

-- ============================================
-- INDEXES FOR OPTIMIZATION (Additional)
-- ============================================

-- Composite indexes for frequently joined tables
CREATE INDEX IF NOT EXISTS idx_student_performance_lookup 
ON student_performance(student_id, exam_id, score);

CREATE INDEX IF NOT EXISTS idx_student_responses_lookup 
ON student_responses(student_id, exam_id, question_id);

CREATE INDEX IF NOT EXISTS idx_questions_exam_lookup 
ON questions(exam_id, question_id);

-- ============================================
-- COMPLETION MESSAGE
-- ============================================

SELECT 'Database setup completed successfully!' AS Status;
SELECT '✓ All 16 tables created' AS Tables;
SELECT '✓ Default admin, courses, and registration fields inserted' AS Data;
SELECT '✓ Views, procedures, and triggers configured' AS Features;
SELECT 'Ready for LMS application deployment!' AS Message;
